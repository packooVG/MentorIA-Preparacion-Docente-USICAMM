# MentorIA USICAMM

Simulador avanzado de entrenamiento tipo USICAMM para Promoción Horizontal docente.

Material de preparación no oficial.
